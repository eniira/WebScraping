import Text.HTML.Scalpel
import Text.Scalpel.Core
import Control.Applicative

scrapingTravessa :: IO (Maybe [String])
scrapingTravessa = scrapeURL "https://www.travessa.com.br/Busca.aspx?d=1&bt=harry%20potter&cta=00&codtipoartigoexplosao=1" fetch_updates
    where
        fetch_updates :: Scraper String [String]
        fetch_updates = chroots (tagSelector "h4" @: [hasClass "search-result-item-heading"]) isolate_update
        
        isolate_update :: Scraper String String
        isolate_update = update
        
        update :: Scraper String String
        update = do 
            header <- text $ selector "a"
            return $ header

            
          
                   

