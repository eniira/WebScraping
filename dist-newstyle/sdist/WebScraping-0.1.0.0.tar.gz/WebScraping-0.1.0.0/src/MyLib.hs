module MyLib (someFunc) where

someFunc :: IO ()
someFunc = putStrLn "someFunc"
